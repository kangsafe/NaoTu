define(function(require, exports, module) {
    return module.exports = window.kityminder.Minder;
});